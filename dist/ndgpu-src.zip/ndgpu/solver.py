"""Multigroup k-eigenvalue solvers: power iteration over the fission source.

Outer loop: standard power iteration on  M phi = (1/k) F phi, where M is the
block (groups) transport-approximation operator and F the fission production
operator. Within one outer iteration the groups are swept Gauss-Seidel style
(downscatter uses the freshest fluxes), and each within-group system is solved
by matrix-free Jacobi-preconditioned CG with a warm start from the previous
outer iteration.

Two angular approximations share this machinery:

- DiffusionEigenSolver: classic diffusion; group state = scalar flux.
- SP3EigenSolver: simplified P3; group state = (Phi1, phi2) moment pair,
  solved as one SPD block system per group (see SP3GroupOperator).

Each outer settles all intergroup scattering equations for its fixed fission
source before updating k or Anderson history. Within-group solves use a fixed
tight tolerance and warm starts. Convergence additionally requires the complete
current-state eigen-equations to balance.

The same outer loop solves the adjoint (importance) problem via
``solve(adjoint=True)``: the leakage+removal operator is self-adjoint, so only
the fission (chi <-> nu_sigma_f) and scattering (group-index transpose)
couplings flip. The adjoint flux weights first-order perturbation theory and
adjoint kinetics parameters.

Everything — fluxes, coupling coefficients, sources — lives on the device for
the entire solve; only per-iteration convergence scalars cross the PCIe bus.
"""

from __future__ import annotations

import inspect
import time
from dataclasses import dataclass, field

import numpy as np

from .backend import asnumpy, device_name, get_backend, synchronize
from .blend import MaterialBlend
from .grid import Grid
from . import kernels
from .linalg import fgmres, get_linear_solver, neumann_preconditioner, pcg
from .materials import Material
from .mesh import Mesh, MeshGrid, MeshGroupOperator
from .sp3 import SP3GroupOperator
from .spn import (CongruentSDPNOperator, SDPNGroupOperator, _SDPN_C, _SDPN_G,
                  _SPN_C, _SPN_G, _congruence_available, _diag_similarity)
from .stencil import BC_VACUUM, BC_ZERO_FLUX, GroupOperator


def _fixed_source_krylov_restart(xp, state, remaining_sweeps):
    """Bound full-group Krylov storage; zero selects ordinary group sweeps."""
    block_bytes = sum(value.nbytes for value in state)
    budget = 256 * 1024**2
    if xp is not np:
        try:
            budget = min(budget, int(xp.cuda.Device().mem_info[0]) // 8)
        except Exception:
            return 0
    # FGMRES retains V and Z; reserve another twenty full blocks for its
    # stacked arguments, residual/operator/preconditioner temporaries, and
    # within-group moment/Krylov work. Include every moment, not just phi0.
    restart = min(30, remaining_sweeps, (budget // block_bytes - 20) // 2)
    return restart if restart >= 2 else 0


def _anderson_source(hist, raw, xp, integration_weights=None):
    """Anderson-accelerated next iterate from a history of (input, raw_output).

    Given the recent (S_j, G(S_j)) pairs (latest last) and the latest raw iterate
    G(S), return the residual-minimizing affine combination that collapses the
    slow fixed-point modes. With fewer than two pairs it is the plain iterate.
    A tiny diagonal regularization and a magnitude guard on the coefficients keep
    it robust; the fixed point (and hence the eigenpair) is unchanged.
    """
    if len(hist) < 2:
        return raw
    res = [Gj - Sj for Sj, Gj in hist]                    # residuals f_j = G_j - S_j
    dres = [res[i] - res[-1] for i in range(len(res) - 1)]
    m = len(dres)
    def inner(a, b):
        product = a * b
        return float(xp.sum(product if integration_weights is None else product * integration_weights))
    A = np.array([[inner(dres[i], dres[j]) for j in range(m)] for i in range(m)])
    b = np.array([-inner(dres[i], res[-1]) for i in range(m)])
    A[np.diag_indices(m)] += 1e-12 * (np.trace(A) + 1e-300)
    try:
        gamma = np.linalg.solve(A, b)
    except np.linalg.LinAlgError:
        return raw
    if not np.all(np.abs(gamma) < 1e4):
        return raw
    out = raw
    for j in range(m):
        out = out + float(gamma[j]) * (hist[j][1] - hist[-1][1])
    return out


@dataclass
class Result:
    k_eff: float
    flux: object  # scalar flux, (G, nx, ny, nz) array on the solve device
    converged: bool
    outer_iterations: int
    inner_iterations: int
    solve_seconds: float
    device: str
    k_history: list = field(default_factory=list)
    source_error_history: list = field(default_factory=list)
    balance_error: float = float('inf')
    failure_reason: str | None = None
    fixed_source_error: float = float('inf')
    fixed_source_tolerance: float = float('nan')
    group_rtol: float = float('nan')
    scalar_flux_min: float = float('nan')
    scalar_flux_scale: float = float('nan')
    scalar_flux_negative_tolerance: float = float('nan')

    @property
    def flux_numpy(self) -> np.ndarray:
        return asnumpy(self.flux)

    def __repr__(self):
        status = "converged" if self.converged else "NOT CONVERGED"
        return (
            f"Result(k_eff={self.k_eff:.6f}, {status}, "
            f"{self.outer_iterations} outers / {self.inner_iterations} inners, "
            f"{self.solve_seconds:.2f} s on {self.device})"
        )


def scatter_stack(xp, sigma_s, G, adjoint, shape, dtype):
    """Dense (G, G, \\*shape) in-scatter matrix: ``S[g][gf]`` is the g' -> g
    coupling, diagonal zeroed and absent couplings materialized as zeros.

    Forward that is ``sigma_s[gf][g]``; the adjoint transposes to
    ``sigma_s[g][gf]``. Kept a module-level function so the transpose -- the
    part that a batched rewrite can silently get backwards, and that only the
    adjoint solves would notice -- is testable without a GPU.
    """
    S = xp.zeros((G, G) + tuple(shape), dtype=dtype)
    for g in range(G):
        for gf in range(G):
            sc = sigma_s[g][gf] if adjoint else sigma_s[gf][g]
            if gf != g and sc is not None:
                S[g, gf] = sc
    return S


class Fields:
    """Per-cell, per-group cross-section fields on the solve device.

    Attributes (lists of (nx, ny, nz) device arrays, length G, except
    sigma_s which is a G x G nested list with None for empty couplings):
    nu_sigma_f, chi, removal, diffusion, sigma_t, sigma_a, sigma_s.

    ``xs_update`` is an optional callable ``fields -> None`` run as the LAST
    step of construction, free to modify the assembled per-cell arrays in
    place. It is the seam for state-dependent cross sections -- a temperature
    feedback is one (see :mod:`ndgpu.feedback`) -- expressed per CELL, which is
    something a per-material table cannot represent.

    Two consequences worth knowing before using it:

    * Operators COPY these arrays when they are built, so mutating a
      ``Fields`` after its solver exists changes nothing. A driver that varies
      the state must rebuild the solver (cheap: ~0.1% of a solve).
    * ``TransientSolver`` rebuilds its fields only when ``problem_at(t)``
      returns different *objects* (an identity check), so a hook that depends
      on state rather than on t would silently freeze at t = 0. Feeding a
      transient back needs that trigger widened first.
    """

    def __init__(self, xp, grid, materials, material_map, dtype,
                 mix_material=None, mix_weight=None, xs_update=None):
        mats = [materials] if isinstance(materials, Material) else list(materials)
        G = mats[0].n_groups
        if any(m.n_groups != G for m in mats):
            raise ValueError("all materials must have the same number of groups")
        self.n_groups = G
        self.fissile = any(m.is_fissile for m in mats)

        # Optional per-cell two-material blend on top of the base integer map:
        # cell XS = (1 - w) * base + w * mix, for a per-cell mix material and
        # weight w (sentinel mix_material < 0 = no blend). This is the volume-
        # mixing homogenization used for a partially-present material -- e.g. a
        # control-drum absorber arc that covers a fraction w of the cell, a
        # partially-inserted rod tip, or a rasterized fuel-pin rim. Cross
        # sections blend linearly (exact reaction-rate averaging under a flat
        # flux); the diffusion coefficient blends *harmonically* (i.e. its
        # transport cross section 1/(3D) volume-averages), so a trace of a
        # strong absorber correctly chokes the cell; the emission spectrum chi
        # blends by fission-production share (see below). Non-blended cells
        # stay bit-identical to the pure-index map.
        mix = mix_material is not None
        blend = MaterialBlend(xp, grid.shape, material_map, len(mats),
                              dtype=dtype, mix_material=mix_material,
                              mix_weight=mix_weight)
        self.blend = blend
        lin, harm = blend.linear, blend.harmonic

        # Per-cell lookup of an arbitrary per-material table (linear blend on
        # mixed cells) -- also used by the transient solver to map per-material
        # kinetics data (1/v, beta) onto the grid, and by the thermal solver to
        # map conductivities onto the same cells under the same rules.
        self.map_table = lin

        def per_group(attr, lookup=None):
            lookup = lookup or lin
            table = np.array([getattr(m, attr) for m in mats])  # (M, G)
            return [lookup(table[:, g]) for g in range(G)]

        self.nu_sigma_f = per_group("nu_sigma_f")
        # chi is an emission *spectrum*, not a cross section: blending it
        # linearly by volume would leave a fissile material mixed with a
        # non-fissile one emitting a spectrum that sums to w -- silently losing
        # (1 - w) of the cell's fission neutrons. The correct merge weights
        # each component's spectrum by its share of the cell's fission
        # production, w * sum_g nuSigma_f (flat-flux proxy; exact whenever at
        # most one component is fissile, e.g. a fuel pin blended with
        # moderator). Cells where neither component is fissile keep the base
        # spectrum (it multiplies a zero source).
        if mix:
            prod = np.array([np.sum(m.nu_sigma_f) for m in mats])
            fission_weighted = lambda table: blend.fission_weighted(table, prod)
        else:
            fission_weighted = lin
        # Per-cell lookup of a per-material quantity that rides on the fission
        # source (chi, delayed fraction beta): mixed cells weight each
        # component by its share of the cell's fission production, so e.g. a
        # fuel/moderator rim cell keeps the fuel's spectrum and beta exactly.
        self.map_table_fission_weighted = fission_weighted

        chi_t = np.array([m.chi for m in mats])  # (M, G)
        self.chi = [fission_weighted(chi_t[:, g]) for g in range(G)]
        # sigma_a is kept alongside removal (= sigma_a + out-scatter) because a
        # temperature feedback adds to ABSORPTION: scaling removal instead
        # would silently scale the out-scatter with it.
        self.sigma_a = per_group("sigma_a")
        self.removal = per_group("removal")
        self.diffusion = per_group("diffusion", lookup=harm)
        self.sigma_t = per_group("sigma_t")

        sig_s = np.array([m.sigma_s for m in mats])  # (M, G, G)
        self.sigma_s = [[lin(sig_s[:, gf, gt]) if np.any(sig_s[:, gf, gt]) else None
                         for gt in range(G)] for gf in range(G)]

        if xs_update is not None:
            xs_update(self)

    def fission_source(self, phi_by_group):
        """Sum_g nuSigma_f,g * phi_g over an iterable of per-group fluxes."""
        src = self.nu_sigma_f[0] * phi_by_group[0]
        for g in range(1, self.n_groups):
            src += self.nu_sigma_f[g] * phi_by_group[g]
        return src


class _PowerIterationSolver:
    """Shared field construction and power-iteration outer loop.

    Subclasses set self.ops (one operator per group, exposing .apply and
    .inv_diag) in _build_operators() and define the group state layout via
    _initial_state / _rhs / _phi.

    Parameters
    ----------
    grid         : Grid
    materials    : a single Material, or a list of Materials indexed by
                   material_map.
    material_map : optional int array of shape grid.shape assigning a material
                   index to every cell (omit for a homogeneous reactor).
    bc           : "zero-flux" (default) or "reflective"; a single string
                   applies to all six faces, or pass 3 per-axis entries /
                   6 per-face values, e.g. bc=(("reflective", "zero-flux"),
                   ("reflective", "zero-flux"), "reflective") for a quarter
                   core with reflective symmetry planes, solved in 2D.
    device       : "auto" | "gpu" | "cpu"
    dtype        : floating dtype for the solve (float64 default; float32
                   roughly doubles GPU throughput at ~1e-6 k accuracy).
    precond_degree : degree of the Neumann-polynomial preconditioner for the
                   inner CG (0 = plain Jacobi, the default). Each degree adds
                   one stencil apply per CG iteration but cuts the iteration
                   count -- and with it the global reductions that are the
                   GPU's only synchronization points. Degree 2-3 is a good
                   setting (cf. E et al., NED 320 (2017), where degree-3
                   Neumann-PCG was the fastest GPU solver for 2e4-3e6 cells).
    linear_solver : "cg" (default), "gmres", or "bicgstab" -- the within-group
                   Krylov solver. The built-in operators are SPD, so CG is
                   right; the other two exist for future non-symmetric
                   operators (see ndgpu.linalg) and as cross-checks, at
                   higher cost.
    symmetric_operator : cylindrical grids only (True default). False builds
                   the natural divergence-form (per-unit-volume) stencil,
                   which is non-symmetric -- pair it with
                   linear_solver="gmres" or "bicgstab". Same discrete
                   solution as the default volume-weighted SPD form; exists
                   as a cross-check and a template for genuinely
                   non-symmetrizable operators. Diffusion only (the SP3
                   block symmetrization assumes SPD moment operators).
    """

    def __init__(self, grid: Grid, materials, material_map=None,
                 bc: str = BC_ZERO_FLUX, device: str = "auto", dtype=np.float64,
                 active=None, mask_bc=BC_VACUUM, precond_degree: int = 0,
                 mix_material=None, mix_weight=None, linear_solver="cg",
                 symmetric_operator: bool = True, hybrid_mask=None,
                 hybrid_confine: bool = False, xs_update=None):
        self.grid = grid
        self.xp = xp = get_backend(device)
        self.device = device_name(xp)
        self.dtype = np.dtype(dtype)
        self.active = active
        self.mask_bc = mask_bc
        # Hybrid transport/diffusion: a per-cell bool mask marking the cells that
        # keep the full angular block (e.g. the control-drum absorber); every
        # other cell runs pure diffusion. The angular blocks restrict their
        # higher moments to this mask, so the driver must likewise zero the
        # higher-moment rows of the RHS outside it (see _rhs). None (default) =
        # the uniform angular approximation everywhere. Diffusion has no higher
        # moments, so it ignores the mask.
        self.hybrid_mask = (None if hybrid_mask is None
                            else xp.asarray(hybrid_mask).astype(self.dtype))
        self.hybrid_confine = bool(hybrid_confine)
        self.symmetric_operator = bool(symmetric_operator)
        self._linsolve = get_linear_solver(linear_solver)
        if (not self.symmetric_operator and self._linsolve is pcg
                and getattr(grid, "geometry", "cartesian") == "cylindrical"):
            raise ValueError(
                "symmetric_operator=False builds the non-symmetric divergence-"
                "form cylindrical stencil; use linear_solver='gmres' or 'bicgstab'")

        # xs_update runs inside Fields, i.e. BEFORE _build_operators and before
        # the fissile check -- so the operators and the "is this a k-eigenvalue
        # problem at all" test both see the post-feedback data. Every solver
        # that subclasses this one (Tri*, SP3, SPN, SDPN) only overrides
        # _build_operators, so they inherit the hook unchanged.
        f = Fields(xp, grid, materials, material_map, self.dtype,
                   mix_material=mix_material, mix_weight=mix_weight,
                   xs_update=xs_update)
        if not f.fissile:
            raise ValueError("no fissile material: k-eigenvalue problem is undefined")
        self.fields = f
        self.n_groups = f.n_groups
        self.nu_sigma_f = f.nu_sigma_f  # list of (nx,ny,nz), len G
        self.chi = f.chi
        self.sigma_s = f.sigma_s

        self._build_operators(grid, f.diffusion, f.sigma_t, f.removal, bc)
        # Cylindrical grids: the operators are volume-weighted, so the
        # isotropic source must carry the same per-cell metric factor
        # (None on Cartesian grids -- the source is used as-is).
        self._src_weight = getattr(self.ops[0], "rhs_weight", None)
        weights = getattr(grid, "integration_weights", None)
        self.integration_weights = None if weights is None else xp.asarray(weights, dtype=self.dtype)
        self.preconds = [neumann_preconditioner(op.apply, op.inv_diag,
                                                int(precond_degree))
                         for op in self.ops]

    # ---- hooks implemented by the angular approximation -------------------
    def _build_operators(self, grid, diffusion, sigma_t, removal, bc):
        raise NotImplementedError

    def _initial_state(self):
        """Per-group solution state, as a list of device arrays."""
        raise NotImplementedError

    def _rhs(self, g, q0):
        """Within-group right-hand side from the isotropic source q0."""
        raise NotImplementedError

    def _phi(self, state_g):
        """Scalar flux phi0 of one group's state (view or expression)."""
        raise NotImplementedError

    # -----------------------------------------------------------------------
    def _make_group_batch(self, state, adjoint, prod):
        r"""Stacked group data for the batched source assembly, or None.

        The per-group Python loops in ``solve`` cost O(G^2) kernel launches per
        outer -- two per (g, g') in-scatter pair plus O(G) for the fission
        source -- which for the 11-group HP-MR library is a few hundred small
        launches per outer, independent of grid size. Stacking the scattering
        matrix into (G, G, \*grid) and the scalar fluxes into (G, \*grid) lets
        one kernel walk a whole row, taking that to O(G).

        Returned only on GPU (the launch cost is the whole point; on CPU the
        sparse loop is strictly better because it skips absent couplings rather
        than multiplying by materialized zeros) and only when the stack is worth
        its memory: G >= 3, and the (G, G, \*grid) array must fit comfortably in
        free device memory. ``S[g][gf]`` is the in-scatter coupling g' -> g with
        the diagonal zeroed, matching the ``gf != g`` skip it replaces.
        """
        xp, G = self.xp, self.n_groups
        if not kernels.use_fused(xp, "groups") or G < 3:
            return None
        phi0 = self._phi(state[0])
        nbytes = G * G * phi0.size * phi0.dtype.itemsize
        try:
            free = xp.cuda.Device().mem_info[0]
        except Exception:
            free = 0
        if free and nbytes > free // 8:
            return None                       # not worth the footprint
        S = scatter_stack(xp, self.sigma_s, G, adjoint, phi0.shape, phi0.dtype)
        W = xp.stack([prod[g] for g in range(G)])
        phi = xp.stack([self._phi(state[g]) for g in range(G)])
        return {"S": S, "W": W, "phi": phi}

    def _fission_source(self, state, weight):
        """Sum_g weight[g] * phi0_g -- the field that drives the outer loop.

        Forward: weight = nu_sigma_f (fission neutron production per cell).
        Adjoint: weight = chi (the transpose of F distributes production by
        nu_sigma_f and collects it against chi, so the driving field is the
        chi-weighted importance).
        """
        src = weight[0] * self._phi(state[0])
        for g in range(1, self.n_groups):
            src += weight[g] * self._phi(state[g])
        return src

    def solve(self, tol_k: float = 1e-7, tol_source: float = 1e-6,
              max_outer: int = 2000, inner_rtol_floor: float = 1e-10,
              k_guess: float = 1.0, verbose: bool = False,
              adjoint: bool = False, anderson_depth: int = 8,
              state0=None, tol_balance: float | None = None,
              tol_fixed_source: float | None = None, max_group_sweeps: int = 100) -> Result:
        """Run power iteration until |dk| < tol_k and the relative L2 change of
        the normalized fission source < tol_source, with the full current-state
        group equation residual < tol_balance (default: tol_source).

        The balance norm is ||loss-RHS||_2/||loss||_2 across all group-state
        components, including moment RHS transforms and source metric weights.
        It uses the actual current flux's fission and scattering sources, not
        the extrapolated fission source supplied to a previous group sweep.

        Each outer first solves the complete fixed-fission-source intergroup
        problem to ``tol_fixed_source`` using at most ``max_group_sweeps``
        Gauss-Seidel sweeps. For three or more groups, remaining sweeps after
        the first are used as flexible-GMRES preconditioner applications to
        accelerate coupled scattering. Its restart uses a storage estimate
        bounded by 256 MiB and one eighth of free GPU memory, including full
        moment states and temporary headroom. This is not a peak-allocation
        guarantee; insufficient or unknown device memory selects
        ordinary group sweeps. None selects max(1e-11, 100*eps(dtype)); an explicit
        fixed-source threshold is never relaxed. The fixed within-group rtol
        is max(8*eps(dtype), min(inner_rtol_floor, 0.1*tol_fixed_source)). These
        internal precision defaults do not relax the caller's source, k or
        final balance thresholds. Result records both resolved tolerances.
        Scalar flux permits only 64*eps(dtype)*max(abs(phi0)) negative roundoff,
        without clipping; zero source groups may be empty. An exhausted group
        budget returns an unconverged result without advancing k or Anderson
        history. Invalid extrapolated sources are rejected whole, not clipped.

        The fission-source fixed point is Anderson-accelerated (a short history of
        source residuals, the same scheme used in the transient step and SPH
        solve): plain power iteration converges at the dominance ratio, which is
        near 1 for a loosely-coupled core (hundreds of outers), whereas Anderson
        collapses the slow modes into a handful. ``anderson_depth`` <= 1 recovers
        the plain power iteration; the converged eigenpair is identical either way.

        adjoint : solve the adjoint (importance) k-eigenproblem M* phi* =
        (1/k) F* phi* instead of the forward one. The within-group operator
        (leakage + removal) is self-adjoint, so only the two energy couplings
        transpose: fission swaps the production weight nu_sigma_f and the
        emission spectrum chi, and scattering swaps its group indices
        (sigma_s[g'->g] becomes sigma_s[g->g']). The dominant eigenvalue is
        identical to the forward k; the eigenvector is the adjoint flux, used
        for adjoint-weighted kinetics and first-order perturbation theory.
        """
        xp, G = self.xp, self.n_groups
        dtype_eps = np.finfo(self.dtype).eps
        tol_balance = tol_source if tol_balance is None else tol_balance
        tol_fixed_source = max(1e-11, 100*dtype_eps) if tol_fixed_source is None else tol_fixed_source
        if not np.isfinite(tol_balance) or tol_balance <= 0:
            raise ValueError('tol_balance must be finite and positive')
        if not np.isfinite(tol_fixed_source) or tol_fixed_source <= 0:
            raise ValueError('tol_fixed_source must be finite and positive')
        if not np.isfinite(inner_rtol_floor) or inner_rtol_floor <= 0:
            raise ValueError('inner_rtol_floor must be finite and positive')
        if isinstance(max_group_sweeps, (bool, np.bool_)) or not isinstance(max_group_sweeps, (int, np.integer)) or max_group_sweeps < 1:
            raise ValueError('max_group_sweeps must be a positive integer')
        if not np.isfinite(k_guess) or k_guess <= 0:
            raise ValueError('k_guess must be finite and positive')
        if adjoint and getattr(self.grid, "geometry", None) == "mesh":
            raise ValueError("mesh adjoints require a separately verified volume inner product")
        weights = self.integration_weights
        def integral(field):
            return xp.sum(field if weights is None else weights * field)
        norm_measure = self.grid.n_cells if weights is None else xp.sum(weights)
        synchronize(xp)
        t0 = time.perf_counter()

        # Anderson reliably accelerates the forward source, but on the adjoint
        # (chi-weighted) source it can lock onto a subdominant eigenpair, so it is
        # disabled there -- plain power iteration is used for the adjoint.
        if adjoint:
            anderson_depth = 1

        # Fission couples groups as F[g,g'] = chi_g * nu_sigma_f_g'. Its
        # transpose F* moves chi to the production weight and nu_sigma_f to the
        # emission spectrum; scattering transposes independently (below).
        prod = self.chi if adjoint else self.nu_sigma_f
        emit = self.nu_sigma_f if adjoint else self.chi

        # state0 warm-starts the power iteration from a previous solve's group
        # state -- the payoff in an outer coupling loop, where each iteration
        # perturbs the cross sections only slightly and a flat start throws
        # away a converged flux shape. It is a starting point only: the
        # converged eigenpair is unchanged, and passing None (the default) is
        # the cold start every existing caller gets.
        state = self._initial_state() if state0 is None else [
            self.xp.asarray(s, dtype=self.dtype).copy() for s in state0]
        batch = self._make_group_batch(state, adjoint, prod)

        def fission_source():
            """Sum_g prod[g] * phi0_g, batched into one kernel when available."""
            if batch is None:
                return self._fission_source(state, prod)
            out = xp.zeros_like(batch["phi"][0])
            return kernels.group_accumulate(xp, out, batch["W"], batch["phi"])

        def group_rhs(g, current_source, current_k):
            q0 = xp.asarray((emit[g] / current_k) * current_source, dtype=self.dtype)
            if batch is not None:
                kernels.group_accumulate(xp, q0, batch["S"][g], batch["phi"])
            else:
                for gf in range(G):
                    s = self.sigma_s[g][gf] if adjoint else self.sigma_s[gf][g]
                    if gf != g and s is not None:
                        q0 += s * self._phi(state[gf])
            if self._src_weight is not None:
                q0 = q0 * self._src_weight
            return self._rhs(g, q0)

        def scattering_rhs(g, values, origins):
            source = xp.zeros_like(self._phi(values[g]))
            for origin in origins:
                scatter = (self.sigma_s[g][origin] if adjoint
                           else self.sigma_s[origin][g])
                if origin != g and scatter is not None:
                    source += scatter * self._phi(values[origin])
            if self._src_weight is not None:
                source *= self._src_weight
            return self._rhs(g, source)

        def coupled_loss(values):
            return xp.stack([
                self.ops[g].apply(values[g])
                - scattering_rhs(g, values, range(G)) for g in range(G)])

        def scattering_preconditioner(residual):
            nonlocal inner_total
            values = xp.zeros_like(residual)
            for g in range(G):
                rhs = residual[g] + scattering_rhs(g, values, range(g))
                if not bool(xp.any(rhs)):
                    continue
                values[g], iterations = self._linsolve(
                    self.ops[g].apply, rhs, values[g],
                    self.ops[g].inv_diag, xp, rtol=rtol,
                    precond=self.preconds[g])
                inner_total += iterations
            return values

        def current_balance(fixed_source=None):
            actual_source = fission_source() if fixed_source is None else fixed_source
            residual2 = loss2 = 0.
            for g in range(G):
                loss = self.ops[g].apply(state[g])
                rhs = group_rhs(g, actual_source, k if fixed_source is None else 1.)
                residual2 += xp.sum((loss-rhs)**2)
                loss2 += xp.sum(loss**2)
            residual2, loss2 = float(residual2), float(loss2)
            if not np.isfinite(residual2) or not np.isfinite(loss2) or loss2 <= 0:
                return float('inf')
            return float(np.sqrt(residual2/loss2))

        def admissible_source(source, negative_tolerance=0.):
            return (bool(xp.all(xp.isfinite(source)))
                    and bool(xp.all(source >= -negative_tolerance))
                    and np.isfinite(float(integral(source))) and float(integral(source)) > 0)

        def physical_scalar_flux():
            # Check the physical scalar trace, never the signed moments. Zero
            # source groups may be empty; permit only rounding-scale negatives
            # relative to the largest physical scalar flux, without clipping.
            nonlocal scalar_min, scalar_scale, scalar_negative_tolerance
            phi = [self._phi(s) for s in state]
            scalar_min = min(float(xp.min(p)) for p in phi)
            scalar_scale = max(float(xp.max(xp.abs(p))) for p in phi)
            scalar_negative_tolerance = 64 * dtype_eps * scalar_scale
            return (all(bool(xp.all(xp.isfinite(p))) for p in phi)
                    and scalar_min >= -scalar_negative_tolerance)

        def physical_source(source):
            if not physical_scalar_flux():
                return False
            # A source assembled from accepted scalar traces can inherit their
            # negative roundoff (notably chi-weighted adjoint sources outside
            # the core). Propagate the existing scalar bound through the
            # nonnegative production weights, without clipping either field.
            # Extrapolated Anderson sources still require exact nonnegativity.
            source_roundoff = scalar_negative_tolerance * sum(prod)
            return admissible_source(source, source_roundoff)

        fsrc = fission_source()
        total = integral(fsrc)
        if not physical_source(fsrc):
            raise RuntimeError("initial fission source must be physical with positive integral")
        k = float(k_guess)

        k_hist, err_hist = [], []
        inner_total = 0
        src_err = 1.0
        converged = False
        balance_error = float('inf')
        fixed_source_error = float('inf')
        failure_reason = 'maximum outer iterations exhausted'
        scalar_min = scalar_scale = scalar_negative_tolerance = float('nan')
        rtol = max(8*dtype_eps, min(inner_rtol_floor, .1*tol_fixed_source))
        hist = []                                # (fsrc_in, raw_iterate) for Anderson

        for outer in range(1, max_outer + 1):
            fsrc_in = fsrc                       # this iteration's input (for Anderson)
            # Anderson's map is P L^-1 E S, not one group sweep with hidden
            # intergroup state. Settle scattering from the FIRST outer and do
            # not use k to scale this fixed-source solve: its production ratio
            # determines the next k after all group equations have balanced.
            scattering_settled = False
            for group_sweep in range(max_group_sweeps):
                for g in range(G):
                    # Keep the FP32 RHS and the batched scalar flux current.
                    rhs = group_rhs(g, fsrc, 1.)
                    if not bool(xp.any(rhs)):
                        # The exact homogeneous solution avoids a Krylov
                        # relative-to-zero stopping target in empty groups.
                        state[g], n_it = xp.zeros_like(state[g]), 0
                    else:
                        state[g], n_it = self._linsolve(
                            self.ops[g].apply, rhs, state[g],
                            self.ops[g].inv_diag, xp, rtol=rtol,
                            precond=self.preconds[g])
                    if batch is not None:
                        batch["phi"][g] = self._phi(state[g])
                    inner_total += n_it
                fixed_source_error = current_balance(fsrc)
                if fixed_source_error <= tol_fixed_source:
                    scattering_settled = True
                    break
                krylov_restart = (_fixed_source_krylov_restart(
                    xp, state, max_group_sweeps - 1)
                    if G >= 3 and group_sweep == 0 else 0)
                if krylov_restart:
                    # Many-group upscatter can have a dominance ratio near
                    # one. Krylov acceleration solves the same fixed-source
                    # equations; each preconditioner application is one group
                    # sweep and consumes the remaining declared sweep budget.
                    rows = []
                    for g in range(G):
                        source = xp.asarray(emit[g] * fsrc, dtype=self.dtype)
                        if self._src_weight is not None:
                            source = source * self._src_weight
                        rows.append(self._rhs(g, source))
                    values, _ = fgmres(
                        coupled_loss, xp.stack(rows), xp.stack(state), None,
                        xp, rtol=.1 * tol_fixed_source,
                        maxiter=max_group_sweeps - 1,
                        restart=krylov_restart,
                        precond=scattering_preconditioner,
                        raise_on_fail=False)
                    state = [values[g] for g in range(G)]
                    if batch is not None:
                        for g in range(G):
                            batch["phi"][g] = self._phi(state[g])
                    fixed_source_error = current_balance(fsrc)
                    scattering_settled = fixed_source_error <= tol_fixed_source
                    break
            if not scattering_settled:
                hist = []
                failure_reason = 'fixed-source group budget exhausted before requested balance'
                break

            fsrc_new = fission_source()
            if not physical_source(fsrc_new):
                hist = []
                failure_reason = 'nonphysical fixed-source iterate'
                break
            total_new = integral(fsrc_new)
            k_new = float(total_new / total)

            diff = fsrc_new / total_new - fsrc / total
            src_err = float(xp.sqrt(integral(diff * diff) / integral((fsrc_new / total_new) ** 2)))
            dk = abs(k_new - k)

            # Normalize so the mean fission source stays at 1 (avoids drift).
            scale = norm_measure / total_new
            for g in range(G):
                state[g] *= scale
            if batch is not None:
                batch["phi"] *= scale         # phi0 is linear in the state
            g_fsrc = fsrc_new * scale                     # raw power iterate, mean 1
            k = k_new

            k_hist.append(k)
            err_hist.append(src_err)
            if verbose:
                print(f"  outer {outer:4d}  k = {k:.8f}  dk = {dk:.2e}  src_err = {src_err:.2e}")

            if dk < tol_k and src_err < tol_source:
                fsrc = g_fsrc
                balance_error = current_balance()
                if (np.isfinite(k) and k > 0 and balance_error < tol_balance
                        and physical_source(fission_source())):
                    converged = True
                    failure_reason = None
                    break
                # A fission-only extrapolation can stagnate while another
                # group's flux is still changing. Discard its stale history,
                # restore the source consistent with this state, and sweep
                # again instead of accepting the apparent fixed point.
                hist = []
                total = integral(fsrc)
                continue

            # Anderson update of the fission source (state stays the plain iterate).
            fsrc = g_fsrc
            if anderson_depth > 1:
                # Anderson can take nonmonotone steps while resolving clustered
                # eigenmodes. Bound growth against the residuals represented
                # by its retained history, rather than restarting whenever a
                # successful extrapolation beats its immediate successor.
                if hist and src_err > 1.1 * max(err_hist[-len(hist)-1:-1]):
                    hist = []
                hist.append((fsrc_in, g_fsrc))
                if len(hist) > anderson_depth:
                    hist.pop(0)
                proposed = _anderson_source(hist, g_fsrc, xp, weights)
                if admissible_source(proposed):
                    fsrc = proposed * (norm_measure / float(integral(proposed)))
                else:
                    # Restore the admissible raw power iterate as a whole;
                    # higher-moment state is untouched and never positivity-clipped.
                    hist = []
            total = integral(fsrc)

        synchronize(xp)
        if not converged:
            balance_error = current_balance()
        physical_scalar_flux()
        # Retain the converged per-group state (moment vectors for the block
        # solvers) so a transient can start from the exact steady moments.
        self.state = state
        return Result(
            k_eff=k,
            flux=xp.stack([self._phi(state[g]) for g in range(G)]),
            converged=converged,
            outer_iterations=outer,
            inner_iterations=inner_total,
            solve_seconds=time.perf_counter() - t0,
            device=self.device,
            k_history=k_hist,
            source_error_history=err_hist,
            balance_error=balance_error,
            failure_reason=failure_reason,
            fixed_source_error=fixed_source_error,
            fixed_source_tolerance=float(tol_fixed_source),
            group_rtol=float(rtol),
            scalar_flux_min=scalar_min,
            scalar_flux_scale=scalar_scale,
            scalar_flux_negative_tolerance=scalar_negative_tolerance,
        )


class DiffusionEigenSolver(_PowerIterationSolver):
    """Multigroup neutron diffusion k-eigenvalue solver (see base for args)."""

    def _build_operators(self, grid, diffusion, sigma_t, removal, bc):
        if self.hybrid_mask is not None:
            raise ValueError("hybrid_mask has no effect on the diffusion solver "
                             "(diffusion has no higher moments); use an SP3/SDPN "
                             "solver to run transport on the masked subdomain")
        self.ops = [GroupOperator(self.xp, grid, diffusion[g], removal[g], bc=bc,
                                  active=self.active, mask_bc=self.mask_bc,
                                  symmetric=self.symmetric_operator)
                    for g in range(self.n_groups)]

    def _initial_state(self):
        return [self.xp.ones(self.grid.shape, dtype=self.dtype)
                for _ in range(self.n_groups)]

    def _rhs(self, g, q0):
        return q0

    def _phi(self, state_g):
        return state_g


class SP3EigenSolver(_PowerIterationSolver):
    """Multigroup simplified-P3 k-eigenvalue solver (see base for args).

    Same interface and cost structure as DiffusionEigenSolver with ~2x the
    work per group; captures leading transport effects that diffusion misses
    (steep flux gradients, strong absorbers, small cores).
    """

    # Angular variant of the two-moment block: "sp3" (Brantley & Larsen) or
    # "sdp1" (simplified double-P1); see SP3GroupOperator. Same solve otherwise.
    _sp_variant = "sp3"

    def _build_operators(self, grid, diffusion, sigma_t, removal, bc):
        if not self.symmetric_operator:
            raise ValueError("symmetric_operator=False is diffusion-only: the "
                             "SP3 block symmetrization assumes SPD moment operators")
        self.ops = [SP3GroupOperator(self.xp, grid, diffusion[g], sigma_t[g],
                                     removal[g], bc=bc, variant=self._sp_variant,
                                     active=self.active, mask_bc=self.mask_bc,
                                     hybrid_mask=self.hybrid_mask,
                                     hybrid_confine=self.hybrid_confine)
                    for g in range(self.n_groups)]

    def _initial_state(self):
        state = []
        for _ in range(self.n_groups):
            u = self.xp.zeros((2,) + self.grid.shape, dtype=self.dtype)
            u[0] = 1.0
            state.append(u)
        return state

    def _rhs(self, g, q0):
        # Symmetrized block RHS: (q0, 5 * (-2/5) q0). Hybrid: the phi2 source is
        # confined to the phi2 subdomain (zero elsewhere), so phi2 stays exactly
        # zero outside it and the first row is pure diffusion there.
        rhs = self.xp.empty((2,) + self.grid.shape, dtype=self.dtype)
        rhs[0] = q0
        rhs[1] = -2.0 * q0
        if self.hybrid_mask is not None:
            rhs[1] = rhs[1] * self.hybrid_mask
        return rhs

    def _phi(self, state_g):
        return state_g[0] - 2.0 * state_g[1]


class SDP1EigenSolver(SP3EigenSolver):
    """Multigroup simplified double-P1 (SDP1) k-eigenvalue solver.

    The N=1 simplified double-PN approximation of Carreno et al., Ann. Nucl.
    Energy 207 (2024) 110675. Same two-moment block, cost, and interface as
    :class:`SP3EigenSolver` (SDP1 and SP3 have the identical number of degrees
    of freedom), differing only in the second-moment diffusion coefficient
    (see :class:`~ndgpu.operator.SP3GroupOperator`). Derived from a half-range
    (double-PN) angular expansion, it resolves discontinuous angular flux more
    faithfully than SP3, giving more accurate results across strongly
    heterogeneous media at equal cost.
    """

    _sp_variant = "sdp1"


def _peek_base_args(args, kwargs):
    """(grid, bc, active, mask_bc) as _PowerIterationSolver.__init__ will see
    them -- for subclasses that must make per-problem decisions before calling
    super().__init__. Falls back to the defaults on a bad call signature (the
    real error is then raised by super().__init__ itself)."""
    sig = inspect.signature(_PowerIterationSolver.__init__)
    try:
        bound = sig.bind_partial(None, *args, **kwargs).arguments
    except TypeError:
        bound = {}
    return (bound.get("grid"), bound.get("bc", BC_ZERO_FLUX),
            bound.get("active"), bound.get("mask_bc", BC_VACUUM))


class SDPNEigenSolver(_PowerIterationSolver):
    """Multigroup simplified double-PN (SDPN) k-eigenvalue solver, order N in
    {1, 2, 3}, in the diffusive U-form of Carreno et al., Ann. Nucl. Energy 207
    (2024) 110675 (see :class:`~ndgpu.operator.SDPNGroupOperator`).

    The group state is the M = N+1 even-moment vector U; the block reaction
    matrix is non-symmetric (the double-PN closure), so the within-group solve
    runs on CG in a symmetrizing basis whenever the tables and boundary
    conditions admit one (see ``symmetrize`` below) and on BiCGStab otherwise. Successive orders match
    the degrees of freedom of SP3/SP5/SP7 respectively and, for strongly
    heterogeneous media, converge toward the transport solution from fewer
    moments. Order 1 is equivalent to :class:`SDP1EigenSolver`, which is kept as
    a faster symmetric (CG) special case; use N = 2, 3 for the higher orders.
    """

    _order = 2
    _coeffs = None                 # None -> SDPN (operator default); _SPN_C -> SPN
    _g_coeffs = _SDPN_G            # Marshak boundary matrices for this family

    def __init__(self, *args, linear_solver: str | None = None,
                 marshak_vacuum: bool = False, symmetrize: bool | None = None,
                 spn_precondition: int | bool = 0, **kwargs):
        # marshak_vacuum: apply the exact moment-coupled Marshak vacuum boundary
        # (-n.D grad U = (g (x) I) U) on vacuum faces instead of the default
        # per-moment Robin (alpha=1/2) approximation -- matches the SPN/SDPN
        # boundary treatment of Carreno et al. (2024).
        #
        # symmetrize (default auto): put the block in a symmetric basis so
        # the within-group solve runs on CG. Auto turns on the *diagonal
        # similarity* whenever the tables admit one (SDP1/SDP2; works with
        # every boundary type except Marshak). SDP3 admits no diagonal
        # similarity, so auto falls back to the full symmetrizing *congruence*
        # (CongruentSDPNOperator) whenever this problem's boundaries allow it
        # -- every face (and the active-mask boundary, if any) reflective or
        # zero-flux, e.g. C5G7; vacuum-Robin faces are moment-dependent and
        # break the symmetry, so those problems keep the plain non-symmetric
        # form. The SPN family is symmetric as-is -- including its Marshak g
        # -- and takes CG without any transform. linear_solver=None resolves
        # to "cg" for a symmetric block and "bicgstab" otherwise.
        #
        # spn_precondition: for the blocks that stay non-symmetric (SDP3 with
        # vacuum faces, any SDPN order with Marshak), precondition BiCGStab/
        # GMRES with `spn_precondition` Neumann (damped-Jacobi) sweeps of the
        # matched-order standard-SPN block -- the symmetric operator that
        # differs from SDPN only in the closure rows of the c tables (same
        # D_i, same boundary structure; with Marshak it carries SPN's own
        # symmetric g). The sweeps are a fixed linear operator, so both
        # BiCGStab and right-preconditioned GMRES remain valid. 0/False = off
        # (plain Jacobi, the default); True = 2 sweeps. Use EVEN sweep counts:
        # the block's moment coupling makes Jacobi non-contractive, so an
        # odd-degree Neumann polynomial is indefinite and stalls the Krylov
        # solve (measured: degree 1 is 10x WORSE than plain Jacobi). Degree 2
        # roughly halves the Krylov applies (Brantley-Larsen SDP3/vacuum and
        # SDP2/Marshak) but each sweep costs one block apply, so on CPU it is
        # net-slower than Jacobi; it is aimed at GPU runs, where applies are
        # streaming kernels and the saved iterations remove global reductions
        # (cf. the same trade-off for precond_degree / Neumann-PCG).
        # Meaningless on a path that already runs symmetric/CG (the companion
        # lives in the untransformed basis), so that combination raises.
        self.marshak_vacuum = bool(marshak_vacuum)
        coeffs = self._coeffs if self._coeffs is not None else _SDPN_C
        r = _diag_similarity(coeffs[self._order])
        identity = r is not None and all(abs(x - 1.0) < 1e-12 for x in r)
        # The symmetrizing congruence (SDP3 CG path) mixes the moments over the
        # whole domain, so it cannot carry a per-moment hybrid mask; the plain
        # non-symmetric block can. Diagonal-similarity symmetrization (SDP1/SDP2)
        # keeps the moments separable and stays compatible.
        hybrid = kwargs.get("hybrid_mask") is not None
        if symmetrize is None:
            if r is not None:
                symmetrize = not identity and not self.marshak_vacuum
            elif hybrid:
                symmetrize = False
            else:
                grid, bc, active, mask_bc = _peek_base_args(args, kwargs)
                symmetrize = (not self.marshak_vacuum and
                              _congruence_available(self._order, grid, bc,
                                                    active, mask_bc,
                                                    coeffs=self._coeffs))
        if hybrid and symmetrize and r is None:
            raise ValueError("hybrid_mask cannot use the symmetrizing-congruence "
                             "path (it mixes moments across the whole domain); "
                             "pass symmetrize=False for a hybrid SDP3 solve")
        self._symmetrize = bool(symmetrize)
        self._diag_sym = r is not None                # similarity vs congruence
        if self._symmetrize and self.marshak_vacuum:
            raise ValueError("symmetrize is incompatible with marshak_vacuum")
        symmetric = identity or self._symmetrize
        self._spn_precond = 2 if spn_precondition is True else int(spn_precondition)
        if self._spn_precond < 0:
            raise ValueError("spn_precondition must be a non-negative sweep count")
        if self._spn_precond and symmetric:
            raise ValueError("spn_precondition applies only to the "
                             "non-symmetric SDPN path; this block is "
                             "symmetric(-ized) and already runs CG")
        if linear_solver is None:
            linear_solver = "cg" if symmetric else "bicgstab"
        super().__init__(*args, linear_solver=linear_solver, **kwargs)
        if self._spn_precond:
            self.preconds = [neumann_preconditioner(op.apply, op.inv_diag,
                                                    self._spn_precond)
                             for op in self._precond_ops]

    def _build_operators(self, grid, diffusion, sigma_t, removal, bc):
        if not self.symmetric_operator:
            raise ValueError("symmetric_operator=False is diffusion-only")
        if self._symmetrize and not self._diag_sym:
            self.ops = [CongruentSDPNOperator(
                self.xp, grid, diffusion[g], sigma_t[g], removal[g],
                order=self._order, bc=bc, active=self.active,
                mask_bc=self.mask_bc, op_cls=self._moment_op_cls,
                coeffs=self._coeffs) for g in range(self.n_groups)]
            return
        bg = self._g_coeffs[self._order] if self.marshak_vacuum else None
        self.ops = [SDPNGroupOperator(self.xp, grid, diffusion[g], sigma_t[g],
                                      removal[g], order=self._order, bc=bc,
                                      active=self.active, mask_bc=self.mask_bc,
                                      op_cls=self._moment_op_cls,
                                      coeffs=self._coeffs, boundary_g=bg,
                                      symmetrize=self._symmetrize,
                                      hybrid_mask=self.hybrid_mask,
                                      hybrid_confine=self.hybrid_confine)
                    for g in range(self.n_groups)]
        if self._spn_precond:
            # Matched-order standard-SPN companion blocks (symmetric tables,
            # same D_i and boundary treatment) for the Neumann preconditioner.
            bg_spn = _SPN_G[self._order] if self.marshak_vacuum else None
            self._precond_ops = [SDPNGroupOperator(
                self.xp, grid, diffusion[g], sigma_t[g], removal[g],
                order=self._order, bc=bc, active=self.active,
                mask_bc=self.mask_bc, op_cls=self._moment_op_cls,
                coeffs=_SPN_C, boundary_g=bg_spn,
                hybrid_mask=self.hybrid_mask,
                hybrid_confine=self.hybrid_confine)
                for g in range(self.n_groups)]

    # Spatial stencil for each moment (overridden by the triangular solver).
    _moment_op_cls = None

    def _initial_state(self):
        M = self._order + 1
        state = []
        for _ in range(self.n_groups):
            u = self.xp.zeros((M,) + self.grid.shape, dtype=self.dtype)
            u[0] = 1.0
            state.append(u)
        return state

    def _rhs(self, g, q0):
        # Isotropic source (fission/k + in-scatter into phi0) distributed over
        # the moment rows by the first column of c^(1).
        w = self.ops[g].src_weights
        M = self._order + 1
        rhs = self.xp.empty((M,) + self.grid.shape, dtype=self.dtype)
        for i in range(M):
            rhs[i] = w[i] * q0
            # Hybrid: confine the higher-moment source to the subdomain so those
            # moments stay exactly zero (pure diffusion) outside it.
            if i > 0 and self.hybrid_mask is not None:
                rhs[i] = rhs[i] * self.hybrid_mask
        return rhs

    def _phi(self, state_g):
        w = self.ops[0].phi0_weights
        phi = w[0] * state_g[0]
        for j in range(1, len(w)):
            if w[j] != 0.0:
                phi = phi + w[j] * state_g[j]
        return phi


class SDP2EigenSolver(SDPNEigenSolver):
    """Simplified double-P2 (SDP2) k-eigenvalue solver -- 3-moment block, the
    degrees of freedom of SP5. See :class:`SDPNEigenSolver`."""

    _order = 2


class SDP3EigenSolver(SDPNEigenSolver):
    """Simplified double-P3 (SDP3) k-eigenvalue solver -- 4-moment block, the
    degrees of freedom of SP7. See :class:`SDPNEigenSolver`."""

    _order = 3


class SPNEigenSolver(SDPNEigenSolver):
    """Standard simplified-PN (SPN) k-eigenvalue solver in the unified U-form,
    order N in {1, 2, 3} = SP3/SP5/SP7 (SP3 here reproduces the dedicated
    symmetric :class:`SP3EigenSolver`). Same block machinery as
    :class:`SDPNEigenSolver` with the standard SPN coefficient matrices, so SP5
    and SP7 -- which ndgpu otherwise lacks -- come for free and enable the
    matched-DoF SPN-vs-SDPN comparison of Carreno et al. (2024): SP3/SDP1,
    SP5/SDP2, SP7/SDP3."""

    _coeffs = _SPN_C
    _g_coeffs = _SPN_G


class SP1EigenSolver(SPNEigenSolver):
    """Standard SP1 k-eigenvalue solver (1-moment block) -- the P1/diffusion
    equation run through the general U-form machinery, so it must reproduce
    :class:`DiffusionEigenSolver` exactly (same D = 1/(3 Sigma_1), removal and
    boundary law; with marshak_vacuum=True the coupled condition degenerates
    to the same alpha = 1/2 Robin term). Exists as the order-0 member of the
    SPN family for like-for-like hierarchy comparisons and as an end-to-end
    consistency check of the block machinery."""

    _order = 0


class SP5EigenSolver(SPNEigenSolver):
    """Standard SP5 k-eigenvalue solver (3-moment block)."""

    _order = 2


class SP7EigenSolver(SPNEigenSolver):
    """Standard SP7 k-eigenvalue solver (4-moment block)."""

    _order = 3


class _MeshSolverMixin:
    """Mesh setup and explicit capability gates for the shared drivers."""

    def __init__(self, mesh, materials, cell_material=None, *,
                 boundary_conditions=None, bc=None, material_map=None, **kwargs):
        self.mesh_discretization = kwargs.pop("mesh_discretization", "tpfa")
        self.mesh_preconditioner_model = kwargs.pop("mesh_preconditioner", None)
        if self.mesh_discretization == "tpfa" and self.mesh_preconditioner_model is not None:
            raise ValueError("mesh_preconditioner is only available for corrected meshes")
        if self.mesh_discretization == "corrected":
            self.mesh_preconditioner_model = self.mesh_preconditioner_model or "tpfa_ilu"
            if self.mesh_preconditioner_model not in ("tpfa_ilu", "tpfa_neumann"):
                raise ValueError("mesh_preconditioner must be 'tpfa_ilu' or 'tpfa_neumann'")
        if self.mesh_discretization not in ("tpfa", "corrected"):
            raise ValueError("mesh_discretization must be 'tpfa' or 'corrected'")
        if self.mesh_discretization == "corrected":
            if kwargs.get("linear_solver") is None:
                kwargs["linear_solver"] = "gmres"
            if kwargs.get("symmetrize"):
                raise ValueError("corrected mesh operators cannot be symmetrized")
            if isinstance(self, SDPNEigenSolver):
                kwargs["symmetrize"] = False
            if kwargs.get("moment_df_model") is not None:
                raise ValueError("corrected mesh discontinuity factors are unsupported")
        face_df = kwargs.pop("face_df", None)
        boundary_df = kwargs.pop("boundary_df", None)
        if (face_df is not None or boundary_df is not None) and not isinstance(self, DiffusionEigenSolver):
            raise ValueError("ambiguous scalar face_df/boundary_df on a mesh moment solver (scalar DF is diffusion-only); use moment_df_model='common_trace' and moment factors")
        model = kwargs.pop("moment_df_model", None)
        moment_face_df = kwargs.pop("moment_face_df", None)
        moment_boundary_df = kwargs.pop("moment_boundary_df", None)
        if model is None and (moment_face_df is not None or moment_boundary_df is not None):
            raise ValueError("moment factors require moment_df_model='common_trace'")
        if model is not None and (model != "common_trace" or
                                  not isinstance(self, SDPNEigenSolver) or self._order != 1):
            raise ValueError("moment_df_model supports only 'common_trace' on order-1 mesh SP3/SDP1")
        self.moment_df_model = model
        if kwargs.get("active") is not None or kwargs.get("hybrid_mask") is not None or kwargs.get("hybrid_confine", False):
            raise ValueError("mesh active/hybrid masks are unsupported; classify exposed faces explicitly")
        if kwargs.pop("df", None) is not None or kwargs.pop("bcf", None) is not None:
            raise ValueError("mesh moment discontinuity factors are unsupported (DF-off only)")
        if kwargs.get("spn_precondition", 0):
            raise ValueError("mesh SPN companion preconditioning is not yet verified")
        if boundary_conditions is not None and bc is not None:
            raise ValueError("pass boundary_conditions or bc, not both")
        specs = boundary_conditions if boundary_conditions is not None else bc
        if isinstance(mesh, MeshGrid):
            grid = mesh if specs is None else MeshGrid(mesh.mesh, specs)
        elif isinstance(mesh, Mesh):
            grid = MeshGrid(mesh, "vacuum" if specs is None else specs)
        else:
            raise TypeError("mesh solver expects a Mesh or MeshGrid")
        if model is not None:
            from .mesh import _mesh_df
            if any(spec not in ("reflective", "zero-flux", "vacuum")
                   for spec in grid.boundary_conditions):
                raise ValueError("common_trace supports only reflective, zero-flux, or coupled Marshak vacuum boundaries")
            if "vacuum" in grid.boundary_conditions and not kwargs.get("marshak_vacuum", False):
                raise ValueError("common_trace vacuum requires marshak_vacuum=True")
            G = materials.n_groups if isinstance(materials, Material) else materials[0].n_groups
            self.moment_face_df = _mesh_df(moment_face_df, (G, len(grid.mesh.faces), 2), "moment_face_df")
            self.moment_boundary_df = _mesh_df(moment_boundary_df, (G, len(grid.mesh.bfaces)), "moment_boundary_df")
            unequal = np.any(self.moment_face_df[..., 0] != self.moment_face_df[..., 1])
            if unequal and kwargs.get("linear_solver") is None:
                kwargs["linear_solver"] = "bicgstab"
        if cell_material is not None and material_map is not None:
            raise ValueError("pass cell_material or material_map, not both")
        mapping = cell_material if cell_material is not None else material_map
        if mapping is not None:
            mapping = np.asarray(mapping)
            if mapping.size != grid.n_cells:
                raise ValueError("cell_material must have one entry per mesh cell")
            mapping = mapping.reshape(grid.shape)
        if isinstance(self, SDPNEigenSolver):
            coeffs = self._coeffs if self._coeffs is not None else _SDPN_C
            if self._order not in coeffs:
                raise ValueError(f"order must be one of {sorted(coeffs)}")
            if kwargs.get("symmetrize") and _diag_similarity(coeffs[self._order]) is None:
                raise ValueError("mesh symmetrizing congruence lacks integrated reaction/source weighting")
        super().__init__(grid, materials, material_map=mapping,
                         bc=grid.boundary_conditions, **kwargs)
        if self._linsolve is pcg and any(not op.symmetric for op in self.ops):
            raise ValueError("CG cannot solve a nonsymmetric mesh moment operator; use bicgstab or gmres")
        if self.mesh_discretization == "corrected":
            if self.mesh_preconditioner_model == "tpfa_ilu":
                from .mesh_preconditioner import build_tpfa_ilu
                self.preconds = [build_tpfa_ilu(op._tpfa, self.xp) for op in self.ops]
            else:
                self.preconds = [neumann_preconditioner(op.tpfa_apply, op.tpfa_inv_diag,
                                                        2) for op in self.ops]

    def _build_operators(self, grid, diffusion, sigma_t, removal, bc):
        if self.mesh_discretization == "corrected":
            from .corrected_mesh_moments import CorrectedMeshMomentOperator
            self.ops = [CorrectedMeshMomentOperator(
                self.xp, grid, diffusion[g], sigma_t[g], removal[g],
                order=self._order, bc=bc, coeffs=self._coeffs,
                boundary_g=(self._g_coeffs[self._order] if self.marshak_vacuum else None))
                for g in range(self.n_groups)]
            return
        if self.moment_df_model is None:
            return super()._build_operators(grid, diffusion, sigma_t, removal, bc)
        if not self.symmetric_operator:
            raise ValueError("symmetric_operator=False is diffusion-only")
        bg = self._g_coeffs[self._order] if self.marshak_vacuum else None
        self.ops = [SDPNGroupOperator(
            self.xp, grid, diffusion[g], sigma_t[g], removal[g],
            order=self._order, bc=bc, op_cls=self._moment_op_cls,
            coeffs=self._coeffs, boundary_g=bg, symmetrize=self._symmetrize,
            moment_df_model=self.moment_df_model,
            moment_face_df=self.moment_face_df[g],
            moment_boundary_df=self.moment_boundary_df[g])
            for g in range(self.n_groups)]


class MeshDiffusionEigenSolver(_MeshSolverMixin, DiffusionEigenSolver):
    """Integrated mesh diffusion; flux shape is ``(G,n_cells,1,1)``.

    ``face_df`` has shape ``(G,n_interior_faces,2)`` in face i/j order;
    ``boundary_df`` has shape ``(G,n_boundary_faces)``. Both default to ones.
    Factors are finite and positive. Unequal face factors require a
    nonsymmetric solver; the default chooses BiCGSTAB, otherwise CG.
    """

    def __init__(self, mesh, materials, cell_material=None, *, face_df=None,
                 boundary_df=None, linear_solver=None, **kwargs):
        from .mesh import _mesh_df
        raw_mesh = mesh.mesh if isinstance(mesh, MeshGrid) else mesh
        if not isinstance(raw_mesh, Mesh):
            raise TypeError("mesh solver expects a Mesh or MeshGrid")
        G = materials.n_groups if isinstance(materials, Material) else materials[0].n_groups
        self.face_df = _mesh_df(face_df, (G, len(raw_mesh.faces), 2), "face_df")
        self.boundary_df = _mesh_df(boundary_df, (G, len(raw_mesh.bfaces)), "boundary_df")
        nonsymmetric = np.any(self.face_df[..., 0] != self.face_df[..., 1])
        if linear_solver is None:
            linear_solver = ("gmres" if kwargs.get("mesh_discretization") == "corrected"
                             else "bicgstab" if nonsymmetric else "cg")
        if nonsymmetric and get_linear_solver(linear_solver) is pcg:
            raise ValueError("CG cannot solve a nonsymmetric mesh diffusion DF operator; use bicgstab or gmres")
        super().__init__(mesh, materials, cell_material, linear_solver=linear_solver, **kwargs)

    def _build_operators(self, grid, diffusion, sigma_t, removal, bc):
        operator_cls = MeshGroupOperator
        if self.mesh_discretization == "corrected":
            from .corrected_mesh import CorrectedMeshGroupOperator
            operator_cls = CorrectedMeshGroupOperator
        self.ops = [operator_cls(self.xp, grid, diffusion[g], removal[g], bc=bc,
                                      symmetric=self.symmetric_operator,
                                      face_df=self.face_df[g], boundary_df=self.boundary_df[g])
                    for g in range(self.n_groups)]


class MeshSDPNEigenSolver(_MeshSolverMixin, SDPNEigenSolver):
    """General integrated mesh SDPN using the existing coefficient tables.

    ``order=1`` is SDP1, ``order=2`` SDP2 and ``order=3`` SDP3. The last
    supports only the plain nonsymmetric path. Coupled Marshak vacuum is
    selected by ``marshak_vacuum=True``; default scalar Robin is also available.

    Order 1 accepts opt-in ``moment_df_model='common_trace'`` with finite
    positive ``moment_face_df`` of shape ``(G,n_interior_faces,2)`` and
    ``moment_boundary_df`` of shape ``(G,n_boundary_faces)`` (default ones).
    One scalar factor corrects every stored moment trace. Unequal face sides
    select BiCGSTAB by default and reject CG. This generic algebraic
    closure does not qualify Serpent scalar DFs as SP3 EPDFs or SDP1 factors.
    Vacuum requires coupled Marshak; reflective and zero-flux are supported.
    Numeric Robin boundaries are excluded from this opt-in closure.
    """

    _moment_op_cls = MeshGroupOperator

    def __init__(self, *args, order=1, **kwargs):
        self._order = order
        super().__init__(*args, **kwargs)


class MeshSPNEigenSolver(MeshSDPNEigenSolver):
    """General integrated mesh SPN: order 0/1/2/3 gives SP1/SP3/SP5/SP7."""

    _coeffs = _SPN_C
    _g_coeffs = _SPN_G


class MeshSP1EigenSolver(MeshSPNEigenSolver):
    """One-moment mesh SP1, equivalent to integrated mesh diffusion."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, order=0, **kwargs)


class MeshSP3EigenSolver(MeshSPNEigenSolver):
    """Mesh SP3 through the general order-1 SPN block (coupled Marshak ready)."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, order=1, **kwargs)


class MeshSDP1EigenSolver(MeshSDPNEigenSolver):
    """Mesh SDP1 through the general order-1 SDPN block."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, order=1, **kwargs)

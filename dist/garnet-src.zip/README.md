# GARNET: A GPU-native Advanced Reactor NEutronics Toolkit

GARNET is a Python reactor-physics solver for multigroup diffusion and
simplified transport (SPN/SDPN). It uses matrix-free finite volumes with
NumPy on CPUs and CuPy on NVIDIA GPUs. The main application is homogenized
full-core analysis, including SPH-corrected cross sections, delayed-neutron
transients, and heat conduction with temperature feedback.

GARNET was formerly called **NDgpu**; that name may still appear in saved
results and older reports. The Python package is now `garnet`.

The core solvers support:

- Cartesian and cylindrical r-z grids, body-fitted triangular meshes, and
  extruded triangular prisms; unstructured meshes for diffusion.
- Criticality and adjoint calculations with diffusion, SP1/3/5/7, and SDP1/2/3.
- Neutron kinetics, coupled thermal transients, and quasi-static acceleration.
- SPH correction and cross-section readers for Griffin and FEMFFUSION data.

## Install

Python 3.10 or later is required. From a checkout:

```bash
python -m pip install -e .              # CPU: NumPy and SciPy
python -m pip install -e '.[cuda12]'    # GPU: also install CuPy for CUDA 12
```

Set `device="cpu"`, `"gpu"`, or `"auto"` on a solve. `auto` selects a GPU
when available and otherwise uses the CPU; `gpu` requires a working CUDA
installation.

## Quickstart

A homogeneous two-group box using the supplied demonstration material:

```python
from garnet import Model, PWR_TWO_GROUP

core = (Model(size=(90, 90, 90), cells=(24, 24, 24))  # lengths in cm
        .fill(PWR_TWO_GROUP)
        .set_boundary("vacuum"))

result = core.run(device="auto")
print(result)             # eigenvalue, convergence, and neutron balance
print(result.k_eff)
flux = result.flux        # NumPy array: (groups, nx, ny, nz)
```

Use `Model` for Cartesian geometry, `HexLattice.build()` → `TriReactor` for
hexagonal or prismatic cores, and `MeshModel` for an existing unstructured
mesh. The [user guide](docs/user_guide.md) walks through materials, geometry,
SPH data, moving control drums, and coupled calculations.

## Documentation

- [User guide](docs/user_guide.md) and [model API reference](docs/model_api.md).
- [Thermal coupling](docs/coupling.md): conduction, feedback, energy balance,
  and preCICE integration.
- [Finite-volume theory report](docs/report.html): discretization and solver
  derivations, with the original July 2026 benchmark snapshot.
- [Examples](examples/) and a [GPU walkthrough](notebooks/colab_coupled_transient_gpu_latest.ipynb).

## Verification and validation

More than 600 automated test cases cover analytic solutions, spatial and
temporal convergence, conservation, and published reactor benchmarks. The
[V&V report](docs/verification_validation.md) maps each core feature to its
tests, states the acceptance criteria, and records the current CPU results.

| Evidence | Report or study |
|---|---|
| Diffusion, SPN/SDPN, mesh convergence, adjoints, and SPH | [Core numerical verification](docs/verification_validation.md#core-numerical-verification) |
| C5G7, BIBLIS, IAEA-3D, VVER-440, TWIGL, and ANL kinetics | [Reactor benchmark comparisons](docs/verification_validation.md#reactor-benchmark-comparisons) |
| Conduction, feedback, energy balance, and coupling | [Thermal and coupling checks](docs/verification_validation.md#thermal-and-coupling-checks) |
| Adaptive BDF, LRA-2D accuracy, and matched-error cost | [Rendered study (PDF)](benchmark-results/lra2d-adaptive-bdf-report/adaptive-bdf-lra-benchmark.pdf) · [data and reproduction](benchmark-results/lra2d-adaptive-bdf-report/) |
| 3-D HP-MR guarded quasi-static transients on GH200 | [Accuracy study and recorded results](benchmark-results/hpmr-iqs-gh200/) |
| T4 GPU accuracy and performance | [3-D transient study](benchmark-results/transient-acceleration/step-08a-adaptive-bdf-gpu-readiness.md) · [optimization studies](benchmark-results/transient-acceleration/) |

These checks cover the numerical methods and the stated benchmark models.
HP-MR demonstration cross sections and homogenization choices still need
assessment for a new design; the reports distinguish these from solver error.
GPU results are tied to the hardware and workloads used in each study.

To run the tests:

```bash
python -m pip install -e '.[test]'
python -m pytest tests                 # regular suite; excludes slow cases
python -m pytest tests -o addopts=     # include the expensive full-core cases
```

Optional tests require CUDA, preCICE, or external reference files. See the
[V&V report](docs/verification_validation.md#reproducing-the-checks) for setup
and the [test layout](tests/README.md) for the verification/validation split.

Licensed under the [GNU GPL v3](LICENSE).
